const cqlt = require('cql-testing');
const path = require('path');

cqlt.test(path.join(__dirname));
